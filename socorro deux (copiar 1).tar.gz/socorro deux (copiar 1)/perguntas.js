criaCartao(
    'supernatural',
    'qual temporada o anjo castiel aparece?',
    '4 temporada'
)

criaCartao(
    'homem aranha',
    'Qual ator faz o 1 homem aranha?',
    'tobey maquire'
)

criaCartao(
    'hora de aventura',
    'que ano foi lançado q animação hora de aventura?',
    '2010'
)

criaCartao(
    'rick and morty',
    'quantas temporadas tem a animação rick and morty?',
    'são 7 temporadas'
)